import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  vetInfo: [],
};

export const vetsSlice = createSlice({
  name: "vet",
  initialState,
  reducers: {
    addVet: (state, action) => {
      state.vetInfo = [action.payload];
    },
  },
});

export const { addVet } = vetsSlice.actions;

export const selectVet = (state) => state.vet.vetInfo;

export default vetsSlice.reducer;
