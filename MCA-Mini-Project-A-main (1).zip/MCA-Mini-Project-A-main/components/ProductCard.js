import { StyleSheet, View } from "react-native";
import React, { useState } from "react";
import { Button, Image, Text } from "@rneui/themed";
import { TouchableOpacity } from "react-native";
import { useDispatch, useSelector } from "react-redux";
import {
  addToBasket,
  removeFromBasket,
  selectBasketItems,
  selectBasketItemsWithId,
} from "../features/basketSlice";
import { auth } from "../firebase";

const ProductCard = ({
  id,
  img,
  name,
  price,
  harvest,
  expiry,
  location,
  farmer,
}) => {
  const [isPressed, setIsPressed] = useState(false);
  const dispatch = useDispatch();
  const items = useSelector((state) => selectBasketItemsWithId(state, id));
  const user = auth.currentUser;

  const addItemToBasket = () => {
    dispatch(addToBasket({ id, name, price, farmer, img }));
  };

  const removeItemFromBasket = () => {
    if (!items.length > 0) return;
    dispatch(removeFromBasket({ id }));
  };
  return (
    <TouchableOpacity
      activeOpacity={0.2}
      onPress={() => setIsPressed(!isPressed)}
    >
      <View style={styles.container}>
        <View>
          <Image
            style={styles.image}
            source={{
              uri: img,
            }}
          />
        </View>
        <View style={styles.innerContainer}>
          <Text style={styles.text}>Product Name: {name}</Text>
          <Text style={styles.text}>Date of Post: {harvest}</Text>
          <Text style={styles.text}>Expiry Date: {expiry}</Text>
          <Text style={styles.text}>Price: {price} / kg</Text>
          <Text style={styles.text}>Location: {location}</Text>
          <Text style={styles.text}>Farmer: {farmer}</Text>
          {isPressed && (
            <View style={styles.incrementButtons}>
              <Button
                title="-"
                color="green"
                containerStyle={styles.decrement}
                onPress={removeItemFromBasket}
                disabled={!items.length}
              />
              <Text style={{ fontSize: 16, fontWeight: "bold" }}>
                {items.length}
              </Text>
              <Button
                title="+"
                color="green"
                containerStyle={styles.increment}
                onPress={addItemToBasket}
                disabled={items.length >= 5}
              />
            </View>
          )}
        </View>
      </View>
    </TouchableOpacity>
  );
};

export default ProductCard;

const styles = StyleSheet.create({
  container: {
    width: 360,
    display: "flex",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    padding: 8,
    borderWidth: 0.5,
    borderColor: "gray",
    borderRadius: 10,
    marginTop: 10,
    marginBottom: 10,
  },
  image: {
    width: 130,
    height: 130,
    borderRadius: 10,
  },
  innerContainer: {
    marginLeft: 30,
  },
  text: {
    fontSize: 12,
    fontWeight: "bold",
    marginTop: 5,
  },
  button: {
    marginTop: 10,
  },
  incrementButtons: {
    display: "flex",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  increment: {
    padding: 5,
  },
  decrement: {
    padding: 5,
  },
});
