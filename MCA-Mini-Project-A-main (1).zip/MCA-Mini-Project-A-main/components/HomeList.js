import { StyleSheet, View } from "react-native";
import React from "react";
import { Text } from "react-native";
import { Image } from "@rneui/themed";

const HomeList = ({ navigation, img, desc }) => {
  return (
    <View style={styles.container}>
      <Image
        style={styles.image}
        source={{
          uri: img,
        }}
      />
      <Text style={styles.text}>{desc}</Text>
    </View>
  );
};

export default HomeList;

const styles = StyleSheet.create({
  container: {
    width: 340,
    display: "flex",
    flexDirection: "row",
    borderWidth: 0.6,
    borderColor: "gray",
    borderRadius: 10,
    padding: 10,
    alignItems: "center",
    backgroundColor: "white",
  },
  text: {
    fontSize: 15,
    fontWeight: "900",
    marginLeft: 12,
  },
  image: {
    width: 80,
    height: 80,
    borderRadius: 50,
  },
});
