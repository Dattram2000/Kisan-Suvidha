import { StyleSheet, Text, View } from "react-native";
import React from "react";
import { Badge, Image } from "@rneui/themed";

const EmpList = ({
  id,
  img,
  name,
  qualification,
  experience,
  speciality,
  status,
}) => {
  console.log(name);

  return (
    <View style={styles.container}>
      <View
        style={{
          flexDirection: "row",
          justifyContent: "space-around",
          marginTop: 20,
          marginBottom: 40,
        }}
      >
        <Image
          style={styles.image}
          source={{
            uri: img,
          }}
        ></Image>
        <Badge status={status ? "success" : "error"} style={styles.badge} />
      </View>
      <View style={styles.vetInfo}>
        <Text style={styles.text}>Name: {name}</Text>
        <Text style={styles.text}>Qualification: {qualification}</Text>
        <Text style={styles.text}>Experience: {experience} Years</Text>
        <Text style={styles.text}>Speciality: {speciality}</Text>
      </View>
    </View>
  );
};

export default EmpList;

const styles = StyleSheet.create({
  container: {
    width: 360,
    display: "flex",
    flexDirection: "row",
    alignItems: "center",
    borderWidth: 0.5,
    borderRadius: 10,
    padding: 8,
    backgroundColor: "white",
    marginBottom: 10,
  },
  image: {
    height: 80,
    width: 80,
    borderRadius: 50,
  },
  vetInfo: {
    marginLeft: 13,
    justifyContent: "space-evenly",
  },
  text: {
    fontSize: 14,
    fontWeight: "bold",
  },
  badge: {},
});
