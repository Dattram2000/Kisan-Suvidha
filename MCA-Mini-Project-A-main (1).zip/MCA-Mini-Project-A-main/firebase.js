import { initializeApp, getApps, getApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore, collection } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyBmsSqLbiG7p--6zmToFF6Dy471P2cqdno",
  authDomain: "kisan-suvidha-8a755.firebaseapp.com",
  projectId: "kisan-suvidha-8a755",
  storageBucket: "kisan-suvidha-8a755.appspot.com",
  messagingSenderId: "378261967215",
  appId: "1:378261967215:web:41cea916a5e1eaaaff189a",
};

let app;

if (getApps.length === 0) {
  app = initializeApp(firebaseConfig);
} else {
  app = getApp();
}

const auth = getAuth();
const db = getFirestore();
const usersColRef = collection(db, "Users");
const vetsColRef = collection(db, "vets");
const enggColRef = collection(db, "Engineers");
const productsColRef = collection(db, "products");
const ordersColRef = collection(db, "orders");

export {
  auth,
  db,
  usersColRef,
  vetsColRef,
  enggColRef,
  productsColRef,
  ordersColRef,
};
