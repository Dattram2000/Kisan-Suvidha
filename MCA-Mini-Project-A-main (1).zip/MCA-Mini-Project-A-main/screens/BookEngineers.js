import { StyleSheet } from "react-native";
import React, { useEffect, useState } from "react";
import { SafeAreaView } from "react-native-safe-area-context";
import { TouchableOpacity } from "react-native";
import EmpList from "../components/EmpList";
import { StatusBar } from "expo-status-bar";
import { getDocs } from "firebase/firestore";
import { enggColRef } from "../firebase";
import { FlatList } from "react-native";

const BookEngineers = () => {
  const [engineers, setEngineers] = useState([]);

  useEffect(() => {
    getDocs(enggColRef)
      .then((snapShot) => {
        const enggData = [];
        snapShot.docs.forEach((doc) => {
          enggData.push({ id: doc.id, ...doc.data() });
        });
        setEngineers(enggData);
      })
      .catch((err) => alert(err.message));
  }, []);

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar style="light" />
      <FlatList
        data={engineers}
        numColumns={1}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <TouchableOpacity>
            <EmpList
              img={item.Image}
              name={item.Name}
              qualification={item.Qualification}
              experience={item.Experience}
              speciality={item.Speciality}
              status={item.Status}
            />
          </TouchableOpacity>
        )}
      />
    </SafeAreaView>
  );
};

export default BookEngineers;

const styles = StyleSheet.create({
  container: {
    width: 380,
    alignItems: "center",
  },
  eng: {
    marginTop: 13,
  },
});
