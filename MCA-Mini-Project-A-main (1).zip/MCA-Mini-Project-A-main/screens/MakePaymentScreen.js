import { StyleSheet, Text, View } from "react-native";
import React from "react";

const MakePaymentScreen = () => {
  return (
    <View>
      <Text>MakePaymentScreen</Text>
    </View>
  );
};

export default MakePaymentScreen;

const styles = StyleSheet.create({});
