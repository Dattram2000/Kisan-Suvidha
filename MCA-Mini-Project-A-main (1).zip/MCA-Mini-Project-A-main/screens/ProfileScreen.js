import { StyleSheet, Text, View } from "react-native";
import React, { useEffect, useLayoutEffect, useState } from "react";
import { SafeAreaView } from "react-native-safe-area-context";
import { ScrollView, TouchableOpacity } from "react-native-gesture-handler";
import { Avatar, Image } from "@rneui/themed";
import { AntDesign } from "@expo/vector-icons";
import { Form, FormItem } from "react-native-form-component";
import { signOut } from "firebase/auth";
import { auth, db, usersColRef } from "../firebase";
import { doc, getDocs, updateDoc } from "firebase/firestore";
import { async } from "@firebase/util";
import { StatusBar } from "expo-status-bar";

const ProfileScreen = ({ navigation }) => {
  const [image, setImage] = useState("");
  const [name, setName] = useState("");
  const [mobile, setMobile] = useState("");
  const [email, setEmail] = useState("");
  const [address, setAddress] = useState("");
  const [state, setState] = useState("");
  const [city, setCity] = useState("");
  const [pincode, setPincode] = useState(0);
  const [isFarmer, setIsFarmer] = useState(false);
  const [farmerId, setFarmerId] = useState(0);
  const [userId, setUserId] = useState("");

  const [user, setUser] = useState([]);

  const loggedInUser = auth.currentUser;

  useLayoutEffect(() => {
    navigation.setOptions({
      headerRight: () => (
        <TouchableOpacity style={{ marginRight: 20 }} activeOpacity={0.3}>
          <Avatar
            rounded
            source={{
              uri: user.photoURL,
            }}
            onPress={signOutUser}
          />
        </TouchableOpacity>
      ),
    });
  });

  const signOutUser = () => {
    signOut(auth)
      .then(navigation.navigate("Login"))
      .catch((err) => console.warn(err));
  };

  useEffect(() => {
    getDocs(usersColRef)
      .then((snapShot) => {
        const allUsers = [];
        snapShot.docs.forEach((doc) => {
          if (doc.data().Email === loggedInUser.email) {
            allUsers.push({ id: doc.id, ...doc.data() });
          }
        });
        setUser(allUsers[0]);
        setUserId(allUsers[0].id);
        setImage(allUsers[0].Image);
        setName(allUsers[0].Name);
        setMobile(allUsers[0].Mobile);
        setEmail(allUsers[0].Email);
        setAddress(allUsers[0].Address);
        setState(allUsers[0].State);
        setCity(allUsers[0].City);
        setPincode(allUsers[0].Pincode);
        setIsFarmer(allUsers[0].Farmer);
        setFarmerId(allUsers[0].FarmerId);
      })
      .catch((err) => {
        if (err) {
          alert(err.message);
        }
      });
  }, []);

  const EditUserProfile = () => {
    updateDoc(doc(db, "Users", userId), {
      Image: image,
      Name: name,
      Mobile: mobile,
      Email: email.toLowerCase(),
      Address: address,
      State: state,
      City: city,
      Pincode: pincode,
      Farmer: isFarmer,
      FarmerId: farmerId,
    }).catch((err) => alert(err.message));
  };

  return (
    <SafeAreaView>
      <StatusBar style="light" />
      <ScrollView>
        <View style={styles.imgView}>
          <Image
            style={styles.image}
            source={{
              uri: image,
            }}
          />
          <View style={styles.imgButton}>
            <TouchableOpacity>
              <AntDesign name="camerao" size={30} color="black" />
            </TouchableOpacity>
            <TouchableOpacity>
              <AntDesign name="picture" size={30} color="black" />
            </TouchableOpacity>
          </View>
        </View>
        <View style={styles.container}>
          <Form
            buttonStyle={{ width: 300, backgroundColor: "green" }}
            buttonText="Edit Profile"
            onButtonPress={EditUserProfile}
          >
            <FormItem
              label="Full Name"
              value={name}
              onChangeText={(text) => setName(text)}
            />

            <FormItem
              label="Mobile"
              value={mobile}
              onChangeText={(text) => setMobile(text)}
            />

            <FormItem
              label="Email"
              value={email}
              onChangeText={(text) => setEmail(text)}
            />

            <FormItem
              label="Address"
              value={address}
              onChangeText={(text) => setAddress(text)}
              textArea={true}
            />

            <FormItem
              label="State"
              value={state}
              onChangeText={(text) => setState(text)}
            />

            <FormItem
              label="City"
              value={city}
              onChangeText={(text) => setCity(text)}
            />

            <FormItem
              label="Pincode"
              value={pincode}
              onChangeText={(text) => setPincode(text)}
            />

            <FormItem
              label="Farmer"
              value={isFarmer ? "Yes" : "No"}
              onChangeText={(text) => setIsFarmer(text)}
            />
          </Form>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

export default ProfileScreen;

const styles = StyleSheet.create({
  imgView: {
    alignItems: "center",
    justifyContent: "center",
    marginTop: 10,
  },
  image: {
    height: 120,
    width: 120,
    borderRadius: 100,
  },
  imgButton: {
    width: 100,
    display: "flex",
    flexDirection: "row",
    justifyContent: "space-between",
    marginTop: 20,
  },
  container: {
    alignItems: "center",
    justifyContent: "center",
  },
});
