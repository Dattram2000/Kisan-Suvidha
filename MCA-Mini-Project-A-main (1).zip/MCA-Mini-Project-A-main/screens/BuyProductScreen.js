import { StyleSheet, View } from "react-native";
import React, { useEffect, useLayoutEffect, useState } from "react";
import { ScrollView } from "react-native-gesture-handler";
import ProductCard from "../components/ProductCard";
import { Avatar, Badge } from "@rneui/themed";
import { TouchableOpacity } from "react-native";
import { auth, productsColRef } from "../firebase";
import { getDocs } from "firebase/firestore";
import { StatusBar } from "expo-status-bar";
import { FlatList } from "react-native";
import { AntDesign } from "@expo/vector-icons";
import { useSelector } from "react-redux";
import { selectBasketItems } from "../features/basketSlice";

const BuyProductScreen = ({ navigation }) => {
  const [products, setProducts] = useState([]);
  const user = auth.currentUser;
  const items = useSelector(selectBasketItems);
  useLayoutEffect(() => {
    navigation.setOptions({
      headerRight: () => (
        <View style={styles.headerIcons}>
          <TouchableOpacity
            activeOpacity={0.2}
            onPress={() => navigation.navigate("Cart")}
          >
            <AntDesign name="shoppingcart" size={26} color="white" />
            <Badge
              containerStyle={{ position: "absolute", top: -4, right: -4 }}
              textStyle={{ fontSize: 10 }}
              value={items.length}
            />
          </TouchableOpacity>
          <TouchableOpacity style={{ marginRight: 20 }} activeOpacity={0.3}>
            <Avatar
              rounded
              source={{
                uri: user?.photoURL,
              }}
            />
          </TouchableOpacity>
        </View>
      ),
    });
  });

  useEffect(() => {
    getDocs(productsColRef)
      .then((snapShot) => {
        const prods = [];
        snapShot.docs.forEach((doc) => {
          prods.push({ id: doc.id, ...doc.data() });
        });
        setProducts(prods);
      })
      .catch((err) => {
        if (err) {
          alert(err.message);
        }
      });
  }, []);
  return (
    <View style={styles.container}>
      <StatusBar style="light" />
      <FlatList
        data={products}
        numColumns={1}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <TouchableOpacity activeOpacity={0.2}>
            <ProductCard
              id={item.id}
              img={item.Image}
              name={item.Name}
              harvest={item.Date_Harvest}
              expiry={item.Date_Expiry}
              price={item.Price}
              location={item.Harvest_Loc}
              farmer={item.Farmer}
            />
          </TouchableOpacity>
        )}
      />
    </View>
  );
};

export default BuyProductScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: "column",
    alignItems: "center",
  },
  headerIcons: {
    width: 100,
    display: "flex",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
});
