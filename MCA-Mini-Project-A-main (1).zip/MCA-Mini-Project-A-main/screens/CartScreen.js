import { StyleSheet, Text, View } from "react-native";
import React from "react";
import { useDispatch, useSelector } from "react-redux";
import {
  removeFromBasket,
  selectBasketItems,
  selectBasketTotal,
} from "../features/basketSlice";
import { useState } from "react";
import { useEffect } from "react";
import { SafeAreaView } from "react-native-safe-area-context";
import { Button, Image } from "@rneui/themed";
import { ScrollView } from "react-native-gesture-handler";

const CartScreen = ({ navigation }) => {
  const [groupedItemsInBasket, setGroupedItemsInBasket] = useState([]);
  const items = useSelector(selectBasketItems);
  const basketTotal = useSelector(selectBasketTotal);
  const dispatch = useDispatch();
  const deliveryCharge = 20;

  useEffect(() => {
    const groupedItems = items.reduce((results, item) => {
      (results[item.id] = results[item.id] || []).push(item);
      return results;
    }, {});
    setGroupedItemsInBasket(groupedItems);
  }, [items]);

  return (
    <SafeAreaView style={styles.view}>
      <ScrollView>
        {Object.entries(groupedItemsInBasket).map(([key, items]) => (
          <View key={key} style={styles.container}>
            <Text>{items.length} x</Text>
            <Image
              source={{ uri: items[0]?.img }}
              style={{ height: 60, width: 60, borderRadius: 50 }}
            />
            <Text>{items[0]?.name}</Text>
            <Text>₹ {items[0]?.price}</Text>
            <Button
              title="Remove"
              containerStyle={styles.button}
              color="green"
              onPress={() => dispatch(removeFromBasket({ id: key }))}
            />
          </View>
        ))}
      </ScrollView>
      <View style={styles.outerContainer}>
        <View style={styles.innerContainer}>
          <Text style={{ fontWeight: "bold" }}>Subtotal</Text>
          <Text style={{ fontWeight: "bold" }}>₹ {basketTotal}</Text>
        </View>
        <View style={styles.innerContainer}>
          <Text style={{ fontWeight: "bold" }}>Delivery Charge</Text>
          <Text style={{ fontWeight: "bold" }}>₹ {deliveryCharge}</Text>
        </View>
        <View style={styles.innerContainer}>
          <Text style={{ fontWeight: "bold" }}>Order Total</Text>
          <Text style={{ fontWeight: "bold" }}>
            ₹ {basketTotal + deliveryCharge}
          </Text>
        </View>
      </View>
      <Button
        title="Place Order"
        color="green"
        containerStyle={styles.submit}
        onPress={() => navigation.navigate("Order")}
      />
    </SafeAreaView>
  );
};

export default CartScreen;

const styles = StyleSheet.create({
  view: {
    flex: 1,
    alignItems: "center",
    justifyContent: "space-between",
  },
  container: {
    width: 360,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-evenly",
    padding: 10,
    marginBottom: 20,
    borderRadius: 20,
    backgroundColor: "lightgray",
  },
  button: {
    borderRadius: 10,
  },
  innerContainer: {
    width: 360,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginTop: 10,
  },
  outerContainer: {
    width: "100%",
    backgroundColor: "lightgray",
    padding: 10,
    borderTopRightRadius: 10,
    borderTopLeftRadius: 10,
  },
  submit: {
    width: "100%",
  },
});
