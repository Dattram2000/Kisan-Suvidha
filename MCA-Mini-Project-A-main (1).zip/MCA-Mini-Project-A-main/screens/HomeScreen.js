import { StyleSheet, View } from "react-native";
import React, { useLayoutEffect } from "react";
import { Avatar, Button } from "@rneui/themed";
import { SafeAreaView } from "react-native-safe-area-context";
import HomeList from "../components/HomeList";
import { ScrollView } from "react-native-gesture-handler";
import { TouchableOpacity } from "react-native";
import { signOut } from "firebase/auth";
import { auth } from "../firebase";
import { StatusBar } from "expo-status-bar";

const HomeScreen = ({ navigation }) => {
  const user = auth.currentUser;
  useLayoutEffect(() => {
    navigation.setOptions({
      headerRight: () => (
        <TouchableOpacity
          style={{ marginRight: 20 }}
          activeOpacity={0.3}
          onPress={signOutUser}
        >
          <Avatar
            rounded
            source={{
              uri: user.photoURL,
            }}
          />
        </TouchableOpacity>
      ),
    });
  });

  const signOutUser = () => {
    signOut(auth)
      .then(navigation.navigate("Login"))
      .catch((err) => console.warn(err));
  };
  return (
    <SafeAreaView style={styles.container}>
      <StatusBar style="light" />
      <ScrollView>
        <View>
          <TouchableOpacity
            style={styles.button}
            activeOpacity={0.2}
            onPress={() => navigation.navigate("Sell")}
          >
            <HomeList
              img="https://imgs.search.brave.com/Az4sgNLfidG-iAyGnNhzaiwmi0rXOrmwQ_GrsyTyDYw/rs:fit:590:590:1/g:ce/aHR0cHM6Ly9pLnBp/bmltZy5jb20vb3Jp/Z2luYWxzL2IyL2Ez/LzYxL2IyYTM2MWVh/NDQzNTFiYjg5MmVm/MmUxNjQ1NWUwNjVm/LmpwZw"
              desc="Sell your harvest !!!"
            />
          </TouchableOpacity>
        </View>

        <TouchableOpacity
          style={styles.button}
          activeOpacity={0.2}
          onPress={() => navigation.navigate("Vets")}
        >
          <HomeList
            img="https://imgs.search.brave.com/1rKp-_klmUSSpoD1XnqCZKg6hDDz-WLky0lwcmtRrFI/rs:fit:1000:1080:1/g:ce/aHR0cHM6Ly9jZG4z/LnZlY3RvcnN0b2Nr/LmNvbS9pLzEwMDB4/MTAwMC80MC8zMi92/ZXQtbG9nby1kZXNp/Z24tdmVjdG9yLTE3/MDc0MDMyLmpwZw"
            desc="Make Appointment with Vet"
          />
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.button}
          activeOpacity={0.2}
          onPress={() => navigation.navigate("Engineers")}
        >
          <HomeList
            img="https://imgs.search.brave.com/9jXv69FI8qMFeWmm2qKxVzUrw22yzLTlbMYlZvtTCPU/rs:fit:1000:1080:1/g:ce/aHR0cHM6Ly9jZG41/LnZlY3RvcnN0b2Nr/LmNvbS9pLzEwMDB4/MTAwMC81OC82OS9l/bmdpbmVlci1sb2dv/LWFuZC1pY29uLWVu/ZXJneS1sYWJlbC1m/b3Itd2ViLW9uLXZl/Y3Rvci0yMjY0NTg2/OS5qcGc"
            desc="Make Appointment with Engineer"
          />
        </TouchableOpacity>

        <Button
          title="Profile"
          onPress={() => navigation.navigate("Profile")}
        />

        <Button title="Shop" onPress={() => navigation.navigate("Shop")} />
      </ScrollView>
    </SafeAreaView>
  );
};

export default HomeScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#E8E8E8",
    paddingHorizontal: 20,
  },
  button: {
    width: 600,
    marginTop: 20,
  },
});
