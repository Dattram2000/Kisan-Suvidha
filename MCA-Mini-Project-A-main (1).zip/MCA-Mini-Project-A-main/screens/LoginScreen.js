import { KeyboardAvoidingView, StyleSheet } from "react-native";
import React, { useEffect, useState } from "react";
import { Image, Input } from "@rneui/base";
import { View } from "react-native";
import { Button } from "@rneui/themed";
import { StatusBar } from "expo-status-bar";
import { onAuthStateChanged, signInWithEmailAndPassword } from "firebase/auth";
import { auth } from "../firebase";
import { Form, FormItem } from "react-native-form-component";

const LoginScreen = ({ navigation }) => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const user = auth.currentUser;

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (authUser) => {
      if (authUser) {
        navigation.replace("Home");
      }
    });
    return unsubscribe;
  }, []);

  const SignInUser = () => {
    signInWithEmailAndPassword(auth, email, password)
      .then(() => {
        navigation.replace("Home");
      })
      .catch((err) => alert(err));
  };
  return (
    <KeyboardAvoidingView style={styles.container}>
      <StatusBar style="light" />
      <Image
        source={{
          uri: "https://imgs.search.brave.com/VaA8AhaAMvDj7o9cn4xmcfVPY0mMsjtJ2VpfK9aAsyo/rs:fit:1200:1200:1/g:ce/aHR0cHM6Ly9sb2dv/cy1kb3dubG9hZC5j/b20vd3AtY29udGVu/dC91cGxvYWRzLzIw/MjAvMDYvU2lnbmFs/X0xvZ28ucG5n",
        }}
        style={styles.logo}
      />

      <Form
        buttonStyle={styles.inputContainer}
        buttonText="Login"
        onButtonPress={SignInUser}
      >
        <FormItem
          label="Email"
          value={email}
          onChangeText={(text) => setEmail(text)}
          asterik
          isRequired={true}
        />

        <FormItem
          label="Password"
          value={password}
          onChangeText={(text) => setPassword(text)}
          asterik
          isRequired={true}
          secureTextEntry
        />
      </Form>

      <Button
        title="Register"
        color="green"
        containerStyle={styles.button}
        onPress={() => navigation.navigate("Register")}
      />
      <View style={{ height: 40 }} />
    </KeyboardAvoidingView>
  );
};

export default LoginScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#E8E8E8",
  },
  logo: {
    height: 150,
    width: 150,
  },
  inputContainer: {
    width: 300,
    marginTop: 20,
    backgroundColor: "green",
  },
  button: {
    height: 40,
    width: 300,
    marginTop: 10,
    borderRadius: 10,
  },
});
