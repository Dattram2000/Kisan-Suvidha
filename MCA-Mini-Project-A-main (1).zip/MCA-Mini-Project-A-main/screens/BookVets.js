import { ScrollView, StyleSheet } from "react-native";
import React, { useEffect, useState } from "react";
import { SafeAreaView } from "react-native-safe-area-context";
import { TouchableOpacity } from "react-native-gesture-handler";
import EmpList from "../components/EmpList";
import { getDocs } from "firebase/firestore";
import { vetsColRef } from "../firebase";
import { StatusBar } from "expo-status-bar";
import { FlatList } from "react-native";
import { useDispatch, useSelector } from "react-redux";
import { selectVet } from "../features/vetsSlice";

const BookVets = ({ navigation }) => {
  const [vets, setVets] = useState([]);
  const dispatch = useDispatch();
  const selectedVet = useSelector(selectVet);

  useEffect(() => {
    getDocs(vetsColRef)
      .then((snapShot) => {
        const vetsData = [];
        snapShot.docs.forEach((doc) => {
          vetsData.push({ id: doc.id, ...doc.data() });
        });
        setVets(vetsData);
      })
      .catch((err) => {
        if (err) {
          alert(err.message);
        }
      });
  }, []);

  const addVetInfo = (id, image, name, qual, exp, spec) => {
    dispatch(addVetInfo({ id, image, name, qual, exp, spec }));
  };

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar style="light" />
      <FlatList
        data={vets}
        numColumns={1}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <TouchableOpacity
            disabled={!item.Status}
            onPress={() =>
              addVetInfo(
                item.id,
                item.Image,
                item.Name,
                item.Qualification,
                item.Experience,
                item.Speciality
              )
            }
          >
            <EmpList
              id={item.id}
              img={item.Image}
              name={item.Name}
              qualification={item.Qualification}
              experience={item.Experience}
              speciality={item.Speciality}
              status={item.Status}
            />
          </TouchableOpacity>
        )}
      />
    </SafeAreaView>
  );
};

export default BookVets;

const styles = StyleSheet.create({
  container: {
    alignItems: "center",
    justifyContent: "space-evenly",
    backgroundColor: "#E8E8E8",
  },
});
