import { StyleSheet, View } from "react-native";
import React, { useEffect, useLayoutEffect, useState } from "react";
import { Form, FormItem } from "react-native-form-component";
import { KeyboardAvoidingView } from "react-native";
import { Avatar, Image, Text } from "@rneui/themed";
import { TouchableOpacity } from "react-native";
import { AntDesign } from "@expo/vector-icons";

const SellProds = ({ navigation }) => {
  const [prodName, setProdName] = useState("");
  const [harvestDate, setHarvestDate] = useState("");
  const [farmerName, setFarmerName] = useState("");
  const [price, setPrice] = useState(0);
  const [harvestLocation, setHarvestLocation] = useState("");
  const [image, setImage] = useState("");

  useLayoutEffect(() => {
    navigation.setOptions({
      headerRight: () => (
        <TouchableOpacity style={{ marginRight: 20 }} activeOpacity={0.3}>
          <Avatar
            rounded
            source={{
              uri: "https://imgs.search.brave.com/Tzz_PRtz7R2vTnJtva6HbZZ9I9YoeybU92P7QL5Wd68/rs:fit:500:500:1/g:ce/aHR0cHM6Ly9ibG9v/bS1vYmd5bi5jb20v/d3AtY29udGVudC91/cGxvYWRzLzIwMTYv/MDkvZHVtbXktcHJv/ZmlsZS1waWMucG5n",
            }}
          />
        </TouchableOpacity>
      ),
    });
  });

  useEffect(() => {
    const unsubscribe = async () => {
      if (Platform.OS !== "web") {
        const { status } =
          await ImagePicker.requestMediaLibraryPermissionsAsync();
        if (status !== "granted") {
          alert("Permission Denied");
        }
      }
    };
    return unsubscribe;
  }, []);

  useEffect(() => {
    const unsubscribe = async () => {
      if (Platform.OS !== "web") {
        const { status } = await ImagePicker.requestCameraPermissionsAsync();
        if (status !== "granted") {
          alert("Permission Denied");
        }
      }
    };

    return unsubscribe;
  }, []);

  const openGallery = async () => {
    let result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.All,
      allowsEditing: true,
      aspect: [4, 3],
      quality: 1,
    });
    if (!result.canceled) {
      setImage(result.assets[0].uri);
    }
  };

  const takePicture = async () => {
    let result = await ImagePicker.launchCameraAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.All,
      allowsEditing: true,
      aspect: [4, 3],
      quality: 1,
    });
    if (!result.canceled) {
      setImage(result.assets[0].uri);
    }
  };

  return (
    <KeyboardAvoidingView>
      <Text h4 style={{ textAlign: "center", marginTop: 20 }}>
        Add Your Product
      </Text>

      <View style={styles.profile}>
        <Image
          source={{
            uri: image
              ? image
              : "https://imgs.search.brave.com/e_CEt-myla21EljF-FhOn5cAeHtqV422sQgTfqL_--M/rs:fit:860:693:1/g:ce/aHR0cHM6Ly93d3cu/a2luZHBuZy5jb20v/cGljYy9tLzI1Mi0y/NTI0Njk1X2R1bW15/LXByb2ZpbGUtaW1h/Z2UtanBnLWhkLXBu/Zy1kb3dubG9hZC5w/bmc",
          }}
          style={styles.image}
        />
        <View style={styles.profileView}>
          <TouchableOpacity onPress={takePicture}>
            <AntDesign name="camerao" size={30} color="black" />
          </TouchableOpacity>
          <TouchableOpacity onPress={openGallery}>
            <AntDesign name="picture" size={30} color="black" />
          </TouchableOpacity>
        </View>
      </View>

      <Form
        buttonStyle={{ width: 200, backgroundColor: "green" }}
        style={styles.container}
      >
        <FormItem
          label="Farmer Name"
          labelStyle={styles.labelName}
          isRequired
          value={farmerName}
          onChangeText={(text) => setFarmerName(text)}
          asterik
          autoFocus
          style={styles.input}
        />

        <FormItem
          label="Product Name"
          isRequired
          value={prodName}
          onChangeText={(text) => setProdName(text)}
          asterik
          style={styles.input}
        />
        <FormItem
          label="Harvest Date"
          isRequired
          value={harvestDate}
          onChangeText={(text) => setHarvestDate(text)}
          asterik
          style={styles.input}
        />

        <FormItem
          label="Harvest Location"
          isRequired
          value={harvestLocation}
          onChangeText={(text) => setHarvestLocation(text)}
          asterik
          style={styles.input}
        />

        <FormItem
          label="Price"
          isRequired
          value={price}
          onChangeText={(text) => setPrice(text)}
          asterik
          style={styles.input}
        />
      </Form>
    </KeyboardAvoidingView>
  );
};

export default SellProds;

const styles = StyleSheet.create({
  container: {
    marginTop: 30,
    alignItems: "center",
    justifyContent: "center",
  },
  input: {
    width: 300,
  },
  profile: {
    alignItems: "center",
    justifyContent: "center",
    marginTop: 20,
  },
  image: {
    width: 120,
    height: 120,
    borderRadius: 100,
  },
  profileView: {
    width: 100,
    display: "flex",
    flexDirection: "row",
    justifyContent: "space-between",
    marginTop: 20,
  },
});
