import { StyleSheet, Text, View } from "react-native";
import React, { useEffect, useState } from "react";
import { ScrollView } from "react-native-gesture-handler";
import { SafeAreaView } from "react-native-safe-area-context";
import { getDocs } from "firebase/firestore";
import { auth, ordersColRef } from "../firebase";
import { Image } from "@rneui/themed";

const OrdersScreen = () => {
  const [userOrders, setUserOrders] = useState([]);
  const loggedInUser = auth.currentUser;

  useEffect(() => {
    getDocs(ordersColRef).then((snapShot) => {
      const orders = [];
      snapShot.docs.forEach((doc) => {
        if (doc.data().Email === loggedInUser.email) {
          orders.push({ id: doc.id, ...doc.data() });
        }
      });
      setUserOrders(orders);
    });
  }, []);

  return (
    <ScrollView>
      <SafeAreaView>
        {userOrders.map((order) => (
          <View style={styles.container}>
            <View>
              <Text>Order ID: {order.id}</Text>
              <Text>Order Placed By: {order.Name}</Text>
              <Text style={{ marginBottom: 5 }}>Ordered Products: </Text>
              {order.Product.map((prod) => (
                <View style={styles.product}>
                  <Image
                    source={{ uri: prod.img }}
                    style={{ height: 40, width: 40, borderRadius: 50 }}
                  />
                  <Text>Price: {prod.price}</Text>
                </View>
              ))}
            </View>
            <View>
              <Text style={{ color: "green" }}>Order Placed</Text>
            </View>
          </View>
        ))}
      </SafeAreaView>
    </ScrollView>
  );
};

export default OrdersScreen;

const styles = StyleSheet.create({
  container: {
    width: 360,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-evenly",
    marginBottom: 20,
    borderColor: "lightgray",
    borderRadius: 10,
    backgroundColor: "lightgray",
  },
  product: {
    width: 120,
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 10,
  },
});
