import { StyleSheet } from "react-native";
import React, { useLayoutEffect, useState } from "react";
import { ScrollView } from "react-native-gesture-handler";
import { SafeAreaView } from "react-native-safe-area-context";
import { Avatar, Image, Text } from "@rneui/themed";
import { Form, FormItem } from "react-native-form-component";
import { TouchableOpacity } from "react-native";

const VetScreen = ({ navigation }) => {
  const [name, setName] = useState("");
  const [mobile, setMobile] = useState("");
  const [email, setEmail] = useState("");
  const [description, setDescription] = useState("");

  useLayoutEffect(() => {
    navigation.setOptions({
      headerRight: () => (
        <TouchableOpacity style={{ marginRight: 20 }} activeOpacity={0.3}>
          <Avatar
            rounded
            source={{
              uri: "https://imgs.search.brave.com/Tzz_PRtz7R2vTnJtva6HbZZ9I9YoeybU92P7QL5Wd68/rs:fit:500:500:1/g:ce/aHR0cHM6Ly9ibG9v/bS1vYmd5bi5jb20v/d3AtY29udGVudC91/cGxvYWRzLzIwMTYv/MDkvZHVtbXktcHJv/ZmlsZS1waWMucG5n",
            }}
          />
        </TouchableOpacity>
      ),
    });
  });
  return (
    <ScrollView>
      <SafeAreaView style={styles.container}>
        <Image
          style={styles.image}
          source={{
            uri: "https://imgs.search.brave.com/7gtT075cUI8NkJxs_E7ufF01fJxhlm1p6-JTXZQuIU4/rs:fit:404:225:1/g:ce/aHR0cHM6Ly90c2Uy/Lm1tLmJpbmcubmV0/L3RoP2lkPU9JUC5R/QUJBbmNRYzBlaExi/OUNGSzlybDNnSGFJ/ciZwaWQ9QXBp",
          }}
        />
        <Text style={styles.text}>Name: Dr. Louden Wright</Text>
        <Text style={styles.text}>Qualification: BSc-IT</Text>
        <Text style={styles.text}>Experience: 5 Years</Text>
        <Text style={styles.text}>Speciality: Dog Specialist</Text>

        <Form
          style={styles.form}
          buttonStyle={{ width: 300, backgroundColor: "green" }}
        >
          <FormItem
            label="Full Name"
            autoFocus
            value={name}
            onChangeText={(text) => setName(text)}
            asterik
            style={styles.item}
          />
          <FormItem
            label="Mobile"
            value={mobile}
            onChangeText={(text) => setMobile(text)}
            asterik
            style={styles.item}
          />
          <FormItem
            label="Email"
            value={email}
            onChangeText={(text) => setEmail(text)}
            asterik
            style={styles.item}
          />
          <FormItem
            label="Problem Description"
            value={description}
            onChangeText={(text) => setDescription(text)}
            asterik
            style={styles.item}
            textArea={true}
          />
        </Form>
      </SafeAreaView>
    </ScrollView>
  );
};

export default VetScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  image: {
    height: 120,
    width: 120,
    borderRadius: 80,
  },
  text: {
    fontSize: 16,
    marginTop: 10,
  },
  form: {
    alignItems: "center",
    justifyContent: "center",
    marginTop: 20,
  },
  item: {
    width: 300,
  },
});
