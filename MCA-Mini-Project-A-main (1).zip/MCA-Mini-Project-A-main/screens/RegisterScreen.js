import { ScrollView, StyleSheet, View } from "react-native";
import React, { useEffect, useState } from "react";
import { StatusBar } from "expo-status-bar";
import { Text } from "@rneui/base";
import { CheckBox, Image } from "@rneui/themed";
import { Dropdown } from "react-native-element-dropdown";
import { AntDesign } from "@expo/vector-icons";
import { auth, usersColRef } from "../firebase";
import { createUserWithEmailAndPassword, updateProfile } from "firebase/auth";
import { addDoc } from "firebase/firestore";
import { TouchableOpacity } from "react-native-gesture-handler";
import * as ImagePicker from "expo-image-picker";
import { Platform } from "react-native";
import { Form, FormItem } from "react-native-form-component";

const data = [
  { label: "Andaman and Nicobar Islands", value: "1" },
  { label: "Andhra Pradesh ", value: "2" },
  { label: "Arunachal Pradesh ", value: "3" },
  { label: "Assam", value: "4" },
  { label: "Bihar", value: "5" },
  { label: "Chandigarh ", value: "6" },
  { label: "Chhattisgarh", value: "7" },
  { label: "Dadra and Nagar Haveli and Daman and Diu", value: "8" },
  { label: "Delhi", value: "9" },
  { label: "Goa", value: "10" },
  { label: "Gujarat", value: "11" },
  { label: "Haryana", value: "12" },
  { label: "Himachal Pradesh", value: "13" },
  { label: "Jammu and Kashmir ", value: "14" },
  { label: "Jharkhand ", value: "15" },
  { label: "Karnataka", value: "16" },
  { label: "Kerala", value: "17" },
  { label: "Ladakh", value: "18" },
  { label: "Lakshadweep", value: "19" },
  { label: "Madhya Pradesh", value: "20" },
  { label: "Maharashtra", value: "21" },
  { label: "Manipur", value: "22" },
  { label: "Meghalaya", value: "23" },
  { label: "Mizoram", value: "24" },
  { label: "Nagaland", value: "25" },
  { label: "Odisha", value: "26" },
  { label: "Puducherry", value: "27" },
  { label: "Punjab", value: "28" },
  { label: "Rajasthan", value: "29" },
  { label: "Sikkim", value: "30" },
  { label: "Tamil Nadu ", value: "31" },
  { label: "Telangana", value: "32" },
  { label: "Tripura", value: "33" },
  { label: "Uttar Pradesh", value: "34" },
  { label: "Uttarakhand", value: "35" },
  { label: "West Bengal", value: "36" },
];

const RegisterScreen = ({ navigation }) => {
  const [name, setName] = useState("");
  const [mobile, setMobile] = useState(0);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [age, setAge] = useState(0);
  const [address, setAddress] = useState("");
  const [state, setState] = useState("");
  const [city, setCity] = useState("");
  const [pincode, setPincode] = useState(0);
  const [aadhaar, setAadhaar] = useState(0);
  const [selectedGender, setGender] = useState(0);
  const [isFarmer, setIsFarmer] = useState(1);
  const [farmerId, setFarmerId] = useState(0);
  const [image, setImage] = useState(null);

  const createUserAccount = () => {
    createUserWithEmailAndPassword(auth, email, password)
      .then((authUser) => {
        updateProfile(auth.currentUser, {
          displayName: name,
          photoURL: image,
        })
          .then(() => {
            addDoc(usersColRef, {
              Image: image,
              Name: name,
              Mobile: mobile,
              Gender: selectedGender,
              Age: age,
              Email: email.toLowerCase(),
              Address: address,
              State: state,
              City: city,
              Pincode: pincode,
              Aadhar: aadhaar,
              Farmer: isFarmer === 0 ? "Yes" : "No",
              FarmerId: farmerId,
            });
          })
          .catch((err) => alert(err.message));
      })
      .catch((err) => alert(err.message));
  };

  useEffect(() => {
    const unsubscribe = async () => {
      if (Platform.OS !== "web") {
        const { status } =
          await ImagePicker.requestMediaLibraryPermissionsAsync();
        if (status !== "granted") {
          alert("Permission Denied");
        }
      }
    };
    return unsubscribe;
  }, []);

  useEffect(() => {
    const unsubscribe = async () => {
      if (Platform.OS !== "web") {
        const { status } = await ImagePicker.requestCameraPermissionsAsync();
        if (status !== "granted") {
          alert("Permission Denied");
        }
      }
    };

    return unsubscribe;
  }, []);

  const openGallery = async () => {
    let result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.All,
      allowsEditing: true,
      aspect: [4, 3],
      quality: 1,
    });
    if (!result.canceled) {
      setImage(result.assets[0].uri);
    }
  };

  const takePicture = async () => {
    let result = await ImagePicker.launchCameraAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.All,
      allowsEditing: true,
      aspect: [4, 3],
      quality: 1,
    });
    if (!result.canceled) {
      setImage(result.assets[0].uri);
    }
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <StatusBar style="light" />
      <View>
        <Form
          buttonStyle={{ backgroundColor: "green", width: 300 }}
          onButtonPress={createUserAccount}
        >
          <View style={styles.profile}>
            <Image
              source={{
                uri: image
                  ? image
                  : "https://imgs.search.brave.com/e_CEt-myla21EljF-FhOn5cAeHtqV422sQgTfqL_--M/rs:fit:860:693:1/g:ce/aHR0cHM6Ly93d3cu/a2luZHBuZy5jb20v/cGljYy9tLzI1Mi0y/NTI0Njk1X2R1bW15/LXByb2ZpbGUtaW1h/Z2UtanBnLWhkLXBu/Zy1kb3dubG9hZC5w/bmc",
              }}
              style={styles.image}
            />
            <View style={styles.profileView}>
              <TouchableOpacity onPress={takePicture}>
                <AntDesign name="camerao" size={30} color="black" />
              </TouchableOpacity>
              <TouchableOpacity onPress={openGallery}>
                <AntDesign name="picture" size={30} color="black" />
              </TouchableOpacity>
            </View>
          </View>

          <FormItem
            label="Full Name"
            value={name}
            onChangeText={(text) => setName(text)}
            autoFocus
            asterik
            isRequired={true}
          />

          <FormItem
            label="Mobile"
            value={mobile}
            onChangeText={(text) => setMobile(text)}
            asterik
            isRequired={true}
          />

          <View style={styles.genderView}>
            <Text style={{ fontWeight: "bold" }}>Gender: </Text>
            <CheckBox
              title="Male"
              checked={selectedGender === 0}
              onPress={() => setGender(0)}
              checkedIcon="dot-circle-o"
              uncheckedIcon="circle-o"
            />
            <CheckBox
              title="Female"
              checked={selectedGender === 1}
              onPress={() => setGender(1)}
              checkedIcon="dot-circle-o"
              uncheckedIcon="circle-o"
            />
          </View>

          <FormItem
            label="Age"
            value={age}
            onChangeText={(text) => setAge(text)}
            asterik
            isRequired={true}
          />

          <FormItem
            label="Email"
            value={email}
            onChangeText={(text) => setEmail(text)}
            asterik
            isRequired={true}
          />

          <FormItem
            label="Create Password"
            value={password}
            onChangeText={(text) => setPassword(text)}
            asterik
            secureTextEntry
            isRequired={true}
          />

          <FormItem
            label="Address"
            value={address}
            onChangeText={(text) => setAddress(text)}
            textArea={true}
            asterik
            isRequired={true}
          />

          <Dropdown
            style={styles.dropdown}
            placeholderStyle={styles.placeholderStyle}
            selectedTextStyle={styles.selectedTextStyle}
            inputSearchStyle={styles.inputSearchStyle}
            data={data}
            search
            maxHeight={300}
            valueField="value"
            labelField="label"
            placeholder="Select State"
            searchPlaceholder="Search..."
            value={state}
            onChange={(item) => {
              setState(item.label);
            }}
          />

          <FormItem
            label="City"
            value={city}
            onChangeText={(text) => setCity(text)}
            asterik
            isRequired={true}
          />

          <FormItem
            label="Pincode"
            value={pincode}
            onChangeText={(text) => setPincode(text)}
            asterik
            isRequired={true}
          />

          <FormItem
            label="Aadhaar Number"
            value={aadhaar}
            onChangeText={(text) => setAadhaar(text)}
            asterik
            isRequired={true}
          />

          <View style={styles.genderView}>
            <Text style={{ fontWeight: "bold" }}>Are you a farmer: </Text>
            <CheckBox
              title="Yes"
              checked={isFarmer === 0}
              onPress={() => setIsFarmer(0)}
              checkedIcon="dot-circle-o"
              uncheckedIcon="circle-o"
            />
            <CheckBox
              title="No"
              checked={isFarmer === 1}
              onPress={() => setIsFarmer(1)}
              checkedIcon="dot-circle-o"
              uncheckedIcon="circle-o"
            />
          </View>

          {isFarmer === 0 && (
            <FormItem
              label="Farmer ID"
              value={farmerId}
              onChangeText={(text) => setFarmerId(text)}
              asterik
              isRequired={true}
            />
          )}
        </Form>
      </View>
    </ScrollView>
  );
};

export default RegisterScreen;

const styles = StyleSheet.create({
  container: {
    alignItems: "center",
  },
  image: {
    height: 120,
    width: 120,
    borderRadius: 100,
  },
  profile: {
    alignItems: "center",
    marginTop: 20,
  },
  profileView: {
    width: 100,
    display: "flex",
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 20,
    marginTop: 20,
  },
  genderView: {
    width: 300,
    display: "flex",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-evenly",
    marginBottom: 20,
  },
  dropdown: {
    height: 50,
    borderRadius: 10,
    backgroundColor: "white",
    marginBottom: 20,
  },
  placeholderStyle: {
    padding: 8,
  },
  selectedTextStyle: {
    fontSize: 16,
    paddingHorizontal: 10,
  },
});
