import { StyleSheet, Text, View } from "react-native";
import React from "react";
import { SafeAreaView } from "react-native-safe-area-context";
import { Form, FormItem } from "react-native-form-component";
import { useState } from "react";
import { auth, ordersColRef } from "../firebase";
import { addDoc } from "firebase/firestore";
import { useSelector } from "react-redux";
import { selectBasketItems } from "../features/basketSlice";

const PlaceOrderScreen = ({ navigation }) => {
  const [name, setName] = useState("");
  const [mobile, setMobile] = useState("");
  const [address, setAddress] = useState("");
  const user = auth.currentUser;
  const orderItems = useSelector(selectBasketItems);

  const placeOrder = () => {
    addDoc(ordersColRef, {
      Name: name,
      Email: user.email,
      Mobile: mobile,
      Address: address,
      Product: orderItems,
    })
      .then(() => navigation.navigate("Orders"))
      .catch((err) => alert(err.message));
  };
  return (
    <SafeAreaView style={styles.container}>
      <Form
        buttonStyle={{ backgroundColor: "green" }}
        buttonText="Proceed to Payment"
        onButtonPress={placeOrder}
      >
        <FormItem
          label="Name"
          value={name}
          onChangeText={(text) => setName(text)}
          isRequired={true}
          asterik
          style={styles.input}
        />
        <FormItem
          label="Mobile"
          value={mobile}
          onChangeText={(text) => setMobile(text)}
          isRequired={true}
          asterik
          style={styles.input}
        />
        <FormItem
          label="Address"
          value={address}
          onChangeText={(text) => setAddress(text)}
          isRequired={true}
          asterik
          style={styles.input}
        />
      </Form>
    </SafeAreaView>
  );
};

export default PlaceOrderScreen;

const styles = StyleSheet.create({
  container: {
    width: 300,
    alignItems: "center",
    justifyContent: "center",
  },
  input: {
    width: 300,
  },
});
