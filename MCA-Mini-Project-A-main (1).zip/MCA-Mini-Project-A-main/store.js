import { configureStore } from "@reduxjs/toolkit";
import basketReducer from "./features/basketSlice";
import vetReducer from "./features/vetsSlice";

export const store = configureStore({
  reducer: {
    basket: basketReducer,
    vet: vetReducer,
  },
});
