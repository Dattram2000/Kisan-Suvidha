import { NavigationContainer } from "@react-navigation/native";
import { createStackNavigator } from "@react-navigation/stack";
import { doc } from "firebase/firestore";
import { StyleSheet } from "react-native";
import { Provider } from "react-redux";
import { auth, db } from "./firebase";
import BookEngineers from "./screens/BookEngineers";
import BookVets from "./screens/BookVets";
import BuyProductScreen from "./screens/BuyProductScreen";
import CartScreen from "./screens/CartScreen";
import EnggScreen from "./screens/EnggScreen";
import HomeScreen from "./screens/HomeScreen";
import LoginScreen from "./screens/LoginScreen";
import MakePaymentScreen from "./screens/MakePaymentScreen";
import OrdersScreen from "./screens/OrdersScreen";
import PlaceOrderScreen from "./screens/PlaceOrderScreen";
import ProfileScreen from "./screens/ProfileScreen";
import RegisterScreen from "./screens/RegisterScreen";
import SellProds from "./screens/SellProds";
import VetScreen from "./screens/VetScreen";
import { store } from "./store";

const Stack = createStackNavigator();

const globalScreenOptions = {
  headerStyle: { backgroundColor: "green" },
  headerTintColor: "white",
};

export default function App() {
  return (
    <NavigationContainer>
      <Provider store={store}>
        <Stack.Navigator
          initialRouteName="Vets"
          screenOptions={globalScreenOptions}
        >
          <Stack.Screen
            options={{
              title: "Login",
              headerTitleAlign: "center",
              headerTintColor: "white",
            }}
            name="Login"
            component={LoginScreen}
          />
          <Stack.Screen
            options={{
              title: "Register",
              headerTitleAlign: "center",
              headerTintColor: "white",
            }}
            name="Register"
            component={RegisterScreen}
          />
          <Stack.Screen
            options={{
              title: "Home",
              headerTitleAlign: "center",
              headerTintColor: "white",
            }}
            name="Home"
            component={HomeScreen}
          />
          <Stack.Screen
            options={{
              title: "Sell",
              headerTitleAlign: "center",
              headerTintColor: "white",
            }}
            name="Sell"
            component={SellProds}
          />
          <Stack.Screen
            options={{
              title: "Vets",
              headerTitleAlign: "center",
              headerTintColor: "white",
            }}
            name="Vets"
            component={BookVets}
          />
          <Stack.Screen
            options={{
              title: "Engineers",
              headerTitleAlign: "center",
              headerTintColor: "white",
            }}
            name="Engineers"
            component={BookEngineers}
          />
          <Stack.Screen
            options={{
              title: "Book Vet",
              headerTitleAlign: "center",
              headerTintColor: "white",
            }}
            name="Book_Vet"
            component={VetScreen}
          />
          <Stack.Screen
            options={{
              title: "Book Engineer",
              headerTitleAlign: "center",
              headerTintColor: "white",
            }}
            name="Book_Engg"
            component={EnggScreen}
          />
          <Stack.Screen
            options={{
              title: "Shop",
              headerTitleAlign: "center",
              headerTintColor: "white",
            }}
            name="Shop"
            component={BuyProductScreen}
          />
          <Stack.Screen
            options={{
              title: "Profile",
              headerTitleAlign: "center",
              headerTintColor: "white",
            }}
            name="Profile"
            component={ProfileScreen}
          />
          <Stack.Screen
            options={{
              title: "Your Cart",
              headerTitleAlign: "center",
              headerTintColor: "white",
              presentation: "modal",
            }}
            name="Cart"
            component={CartScreen}
          />
          <Stack.Screen
            options={{
              title: "Your Order",
              headerTitleAlign: "center",
              headerTintColor: "white",
              presentation: "modal",
            }}
            name="Order"
            component={PlaceOrderScreen}
          />
          <Stack.Screen
            options={{
              title: "Make Payment",
              headerTitleAlign: "center",
              headerTintColor: "white",
              presentation: "modal",
            }}
            name="MakePayment"
            component={MakePaymentScreen}
          />
          <Stack.Screen
            options={{
              title: "Your Orders",
              headerTitleAlign: "center",
              headerTintColor: "white",
              presentation: "modal",
            }}
            name="Orders"
            component={OrdersScreen}
          />
        </Stack.Navigator>
      </Provider>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    alignItems: "center",
    justifyContent: "center",
  },
});
